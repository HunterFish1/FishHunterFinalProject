import tkinter as tk
from tkinter import messagebox

class WelcomeWindow:
    def __init__(self, master, callback):
        self.master = master
        self.callback = callback

        self.frame = tk.Frame(self.master, bg="#f0f0f0")
        self.frame.pack(expand=True, fill="both")

        self.label_welcome = tk.Label(self.frame, text="Welcome to Personal Budget Manager!", font=("Arial", 16), bg="#f0f0f0")
        self.label_welcome.pack(pady=20)

        self.button_start = tk.Button(self.frame, text="Start", font=("Arial", 12), command=self.start_application, bg="#4CAF50", fg="white", relief="flat")
        self.button_start.pack(pady=10, padx=50, ipadx=20, ipady=5)

        self.line = tk.Frame(self.frame, height=2, width=300, bg="#d9d9d9")
        self.line.pack(pady=20)

    def start_application(self):
        self.callback()
        self.master.withdraw()

class BudgetManagerWindow:
    def __init__(self, master, welcome_window):
        self.master = master
        self.welcome_window = welcome_window

        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master, bg="#f0f0f0")
        self.frame.pack(expand=True, fill="both")

        # Create labels
        self.label_income = tk.Label(self.frame, text="Income:", font=("Arial", 14), bg="#f0f0f0")
        self.label_income.grid(row=0, column=0, padx=10, pady=5, sticky="w")

        self.label_expenses = tk.Label(self.frame, text="Expenses:", font=("Arial", 14), bg="#f0f0f0")
        self.label_expenses.grid(row=1, column=0, padx=10, pady=5, sticky="w")

        # Create entry widgets
        self.entry_income = tk.Entry(self.frame, font=("Arial", 12), bg="#ffffff")
        self.entry_income.grid(row=0, column=1, padx=10, pady=5)

        self.entry_expenses = tk.Entry(self.frame, font=("Arial", 12), bg="#ffffff")
        self.entry_expenses.grid(row=1, column=1, padx=10, pady=5)

        # Create buttons
        self.button_calculate = tk.Button(self.frame, text="Calculate", font=("Arial", 12), command=self.calculate_budget, bg="#4CAF50", fg="white", relief="flat")
        self.button_calculate.grid(row=2, columnspan=2, padx=10, pady=10, ipadx=20, ipady=5)

        self.button_exit = tk.Button(self.frame, text="Exit", font=("Arial", 12), command=self.exit_application, bg="#f44336", fg="white", relief="flat")
        self.button_exit.grid(row=3, columnspan=2, padx=10, pady=5, ipadx=20, ipady=5)

    def calculate_budget(self):
        try:
            income = float(self.entry_income.get())
            expenses = float(self.entry_expenses.get())
            remaining_balance = income - expenses
            message = f"Remaining balance: ${remaining_balance:.2f}"
            messagebox.showinfo("Budget Calculation", message)
        except ValueError:
            messagebox.showerror("Error", "Please enter valid numerical values.")

    def exit_application(self):
        self.master.destroy()
        self.welcome_window.master.deiconify()

class PersonalBudgetManagerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Personal Budget Manager")
        self.master.geometry("400x300")

        self.open_welcome_window()

    def open_welcome_window(self):
        self.welcome_window = WelcomeWindow(self.master, self.open_budget_manager_window)

    def open_budget_manager_window(self):
        self.master.withdraw()  # Hide the main window
        self.budget_manager_window = BudgetManagerWindow(tk.Toplevel(), self.welcome_window)

def main():
    root = tk.Tk()
    app = PersonalBudgetManagerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

